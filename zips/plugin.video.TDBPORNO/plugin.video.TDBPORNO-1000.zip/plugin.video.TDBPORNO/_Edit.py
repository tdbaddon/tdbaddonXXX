import xbmcaddon

MainBase = 'http://www.kgroup.tcomputers.ca/@TDBPORNO/TDBPORNO-HOME.txt'
addon = xbmcaddon.Addon('plugin.video.TDBTESTER')












