import xbmcaddon

MainBase = 'http://www.kgroup.tcomputers.ca/@TDBPORNO/TDBPORNO-HOME.xml'
addon = xbmcaddon.Addon('plugin.video.TDBPORNO')












